from django.urls import path
from . import views

urlpatterns = [
    path('twitter/', views.twitter_view, name='twitter'),
    path('achievements/', views.achievements_view, name='achievements'),
    path('about/', views.about_view, name='about'),
    path('products/', views.products_view, name='products'),
    path('news/', views.news_view, name='news'),
    path('faq/', views.faq_view, name='faq'),
    path('career/', views.career_view, name='career'),
]
