from django.shortcuts import render
from .models import Twitter, SocialAchievements, About, Products, News, FAQ, Career

def twitter_view(request):
    twitter_data = Twitter.objects.all()
    return render(request, 'twitter.html', {'twitter_data': twitter_data})

def achievements_view(request):
    achievements_data = SocialAchievements.objects.all()
    return render(request, 'achievements.html', {'achievements_data': achievements_data})

def about_view(request):
    about_data = About.objects.all()
    return render(request, 'about.html', {'about_data': about_data})

def products_view(request):
    products_data = Products.objects.all()
    return render(request, 'products.html', {'products_data': products_data})

def news_view(request):
    news_data = News.objects.all()
    return render(request, 'news.html', {'news_data': news_data})

def faq_view(request):
    faq_data = FAQ.objects.all()
    return render(request, 'faq.html', {'faq_data': faq_data})

def career_view(request):
    career_data = Career.objects.all()
    return render(request, 'career.html', {'career_data': career_data})
