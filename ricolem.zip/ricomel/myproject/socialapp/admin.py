from django.contrib import admin
from .models import Twitter, SocialAchievements, About, Products, News, FAQ, Career

admin.site.register(Twitter)
admin.site.register(SocialAchievements)
admin.site.register(About)
admin.site.register(Products)
admin.site.register(News)
admin.site.register(FAQ)
admin.site.register(Career)
